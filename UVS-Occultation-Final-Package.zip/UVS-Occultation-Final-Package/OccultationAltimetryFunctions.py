import numpy as np
import pyshtools
# coefs is an array of entries of the form [c, s, l, m] sorted so l,m goes
#      00,10,11,20,21,22,...
# coords is an array of entries of the form [phii1,thetai1,phii2,thetai2]  

def changeCoef(coefs,l,m,h): # Returns a new array with C/S_lm by h
    # Note that this assumes "coefs" doesn't include a tide amplitude entry
    index = int(l*(l+1)/2+np.abs(m))
    coefs = np.copy(coefs)
    if m>=0: # means C needs cnphanging
        j = 0
    else: # means S needs changing
        j = 1
    coefs[index,j] = coefs[index,j]+h
    return coefs
        
def coefArrayToVector(coefarray,lmax,phase=True):
    # Converts [C,S,l,m] to [amp,C00,C10,C11,S11,C20,C21,S21,C22,S22,C30,C31,S31...]
    if phase:
        res = [coefarray[0][0]]
    else:
        res = []
    for l in range(lmax+1):
        for m in range(l+1):
            i = int(l*(l+1)/2+m+phase)
            res.append(coefarray[i][0])
            if m > 0:
                res.append(coefarray[i][1])
    return res

def coefVectorToArray(coefvector,lmax,phase=True): 
    # Converts [amp,C00,C10,C11,S11,C20,C21,S21,C22,S22,C30,C31,S31...] to [C,S,l,m]
    coefvector = coefvector.tolist()[:]
    if phase:
        res = [[coefvector.pop(0),0,-1,0]]
    else:
        res = []
    for l in range(lmax+1):
        for m in range(l+1):
            if m == 0:
                res.append([coefvector.pop(0),0,l,m])
            else:
                res.append([coefvector.pop(0),coefvector.pop(0),l,m])
    return np.array(res)

def computeAltitude(coefs, phi, legendres,lmax,ms=np.array([]),ls=np.array([])): 
    # Computes height of topography at points (phi,theta) with legendres
    # note this function doesn't need theta because legendres know it
    if ls.size == 0:
        ls = np.linspace(0,lmax,lmax+1,dtype=int)
    if ms.size == 0:
        ms = np.linspace(ls*0,(ls*0+1)*lmax,lmax+1,dtype=int)
    includes = ms <= np.swapaxes(ms,0,1)
    indices= (ms+ls*(ls+1)/2).astype(int)
    h = np.sum(includes*legendres[indices]*(coefs[indices,0]*np.cos(ms*phi)+coefs[indices,1]*np.sin(ms*phi)))
    return h

def computeChord(phi1,theta1,phi2,theta2,coefs,lmax):
    # Computes the length of a chord between the given points
    cosg = np.sin(theta2)*np.sin(theta1)*np.cos(phi2-phi1)
    cosg += np.cos(theta2)*np.cos(theta1)
    legendres1 = pyshtools.legendre.PlmBar(lmax, np.cos(theta1))
    legendres2 = pyshtools.legendre.PlmBar(lmax, np.cos(theta2))
    # computing ms and ls once saves time    
    ls = np.linspace(0,lmax,lmax+1,dtype=int)
    ms = np.linspace(ls*0,(ls*0+1)*lmax,lmax+1,dtype=int)
    (h1,h2) = computeTopos(coefs,phi1,phi2,legendres1,legendres2,lmax,ms=ms,ls=ls)
    chord = np.sqrt(h1**2 + h2**2 - 2*h1*h2*cosg)
    return chord

def computeRadar(phi,theta,coefs,lmax):
    # Computes the altitude of the given point
    legendres = pyshtools.legendre.PlmBar(lmax, np.cos(theta))
    return computeAltitude(coefs,phi,legendres,lmax)

def computeTopos(coefs, phi1, phi2, legendres1, legendres2,lmax,ms=np.array([]),ls=np.array([])): 
    # Computes height of topography at points (phi1,theta1) and (phi2,theta2)
    # note this function doesn't need theta1/2 because legendres1/2 know it
    if ls.size == 0: #only compute this if not provided, computechord provides them        
        ls = np.linspace(0,lmax,lmax+1,dtype=int)
    if ms.size == 0:
        ms = np.linspace(ls*0,(ls*0+1)*lmax,lmax+1,dtype=int)
    # "includes" is 1 for m <= l and 0 for m > l
    includes = ms<=np.swapaxes(ms,0,1)
    indices = (ms+ls*(ls+1)/2).astype(int)
    h1 = np.sum(includes*legendres1[indices]*(coefs[indices,0]*np.cos(ms*phi1)+coefs[indices,1]*np.sin(ms*phi1)))
    h2 = np.sum(includes*legendres2[indices]*(coefs[indices,0]*np.cos(ms*phi2)+coefs[indices,1]*np.sin(ms*phi2)))
    return (h1,h2)

def getM(index):
    # Extracts m from the index in [C00,C10,C11,S11,C20,C21,S21,C22,S22]
    m = index - int(np.sqrt(index))**2 # subtracting l^2
    if m%2 == 0: # distinguishing C from S
        m = -m/2
    else:
        m = (m+1)/2
    return int(m)

def getL(index):
    # Extracts l from the index in [C00,C10,C11,S11,C20,C21,S21,C22,S22]
    # doesn't deserve its own function, but symmetry is nice, used to be uglier
    return int(np.sqrt(index))

def improveRandomly(chords, coords, coefs, attemps = 10, amplitude = 0.00001):
    # NOT USED BY ANYTHING
    # This function existed to test the analytic solution by brute force 
    #
    # Tries to retrieve coefficients using gradient descent: assuming a shape
    # model, randomly perturbing it. It then forward calculates the chords
    # and it keeps whichever shape model recreates the chords better. It 
    # repeats this for a while until it finds a (possibly local) minimum.
    #
    # "attempts" is the maximum number of times the fit is allowed to not
    # improve before the program quits, O(10) seems to work well. "amplitude"
    # is used to increase or decrease how aggressive the perturbations are,
    # trading off run time vs likelihood of missing minima
    lmax = int(coefs[-1][2])
    best = 0
    tides = len(coords[0]) == 5
    fails = 0
    perturbation = np.copy(coefs*0)
    bestchords = makeChords(coords,coefs,tides,lmax)
    best = np.sqrt(np.mean((np.array(chords)-np.array(bestchords))**2))
    while True:
        scoefs = np.copy(perturbation + coefs)
        schords = makeChords(coords,scoefs,tides,lmax)
        rms = np.sqrt(np.mean((np.array(chords)-np.array(schords))**2))
        if rms < best:
            best = rms
            bestchords = schords
            coefs = np.copy(scoefs)
            fails = 0
            perturbation = 1.5*perturbation
        else:
            fails += 1
            perturbation = np.copy(np.random.normal(coefs*0,amplitude*(best**2))*(coefs != coefs.astype(int)))
            if fails == attemps:
                return coefs
            
def loadMoonHarmonics(filename='moonharmonics.txt',lmax=30):
    # Pulls harmonic coefficients from a file
    f = open(filename)
    harmonics = []
    for l in range(lmax+1):
        for m in range(l+1):
            line = f.readline()
            line = np.array(line.strip().split()).astype(float)
            harmonics.append([line[2]/1000.,line[3]/1000.,int(line[0]),int(line[1])]) # m to km
    f.close()
    return np.array(harmonics)

def makeChords(coords,coefs,tides,lmax):
    res = []
    for j in range(len(coords)):
        tcoefs = np.copy(coefs)
        if not tides:
            [phi1,theta1,phi2,theta2]=coords[j]
        else:
            [phi1,theta1,phi2,theta2,phase] = coords[j]
            tcoefs[1:] = changeCoef(tcoefs[1:],2,2,-1*tcoefs[0][0]*np.cos(phase)/1.93649167)
            tcoefs[1:] = changeCoef(tcoefs[1:],2,0,2*tcoefs[0][0]*np.cos(phase)/6.70820394)
        res.append(computeChord(phi1,theta1,phi2,theta2,tcoefs[tides:],lmax))
    return res

def makeRadars(coords,coefs,tides,lmax):
    res = []
    for j in range(len(coords)):
        tcoefs = np.copy(coefs)
        if not tides:
            [phi,theta]=coords[j]
        else:
            [phi,theta,phase] = coords[j]
            tcoefs[1:] = changeCoef(tcoefs[1:],2,2,-1*tcoefs[0][0]*np.cos(phase)/1.93649167)
            tcoefs[1:] = changeCoef(tcoefs[1:],2,0,2*tcoefs[0][0]*np.cos(phase)/6.70820394)
        res.append(computeRadar(phi,theta,tcoefs[tides:],lmax))
    return res

def makeA(chords, coefs, coords):
    # Makes a matrix of A_ij = dchord_i/dcoef_j, using analytic solution for
    # derivatives. Includes phase info in coefs[0] (l=-1, m=0) and coords[:,4]
    lmax = int(coefs[-1][2])
    amat = np.zeros((len(chords),len(coefArrayToVector(coefs,lmax))))    
    ls = np.linspace(0,lmax,lmax+1,dtype=int)
    ms = np.linspace(ls*0,(ls*0+1)*lmax,lmax+1,dtype=int)
    #ugly but should save a ton of time
    getms = np.linspace(0,len(amat[0])-1,len(amat[0]))
    getls = np.linspace(0,len(amat[0])-1,len(amat[0]))
    for i in range(len(getms)):
        getms[i] = getM(i)
        getls[i] = getL(i)
    # cosgs is an array of cos(gamma), where gamma is the angle between (phi1,theta1) and (phi2,theta2)
    cosgs = np.sin(coords[:,3])*np.sin(coords[:,1])*np.cos(coords[:,0]-coords[:,2]) + np.cos(coords[:,3])*np.cos(coords[:,1])
    for i in range(len(amat)): # Makes each row of A_ij
        [phi1,theta1,phi2,theta2,phase] = coords[i]
        cosg = cosgs[i]
        # get array of legendre polynomials, not sure if this PlmBar is the
        # normalization I want though. Note that the array that gets returned 
        # is [P00(cos(theta)),P10(),P11,P20,P21,P22,P30,P31,P32,P33,...]
        legendres1 = pyshtools.legendre.PlmBar(lmax, np.cos(theta1))
        legendres2 = pyshtools.legendre.PlmBar(lmax, np.cos(theta2))
        # Modifies the degree 2 coefficient(s) according to the tidal amplitude in coefs
        # I'm not entirely sure this is wise? But it fits the idea behind
        # using the fitted coefficients to update the coefficients
        scoefs = np.copy(coefs)
        if lmax >= 2:
            scoefs[1:] = changeCoef(scoefs[1:],2,2,-1*scoefs[0][0]*np.cos(phase)/1.93649167)
            scoefs[1:] = changeCoef(scoefs[1:],2,0,2*scoefs[0][0]*np.cos(phase)/6.70820394)
        # Computes heights of (phi1,theta1) and (phi2,theta2) assuming coefs
        # Note that for this to work well without iterating, need h1 \approx h2 \approx R = C00 = coefs[1][0]
        (h1,h2) = computeTopos(scoefs[1:],phi1,phi2,legendres1,legendres2,lmax,ms=ms,ls=ls)
        for j in range(len(amat[i])-1): # Filling each entry in amat
            # Converting between different ways to index
            m = getms[j]
            l = getls[j]
            index = int(l*(l+1)/2+np.abs(m))
            if m >=0: # Filling C_lm
                res = float((h2-h1*cosg)*np.cos(m*phi2)*legendres2[index])
                res += float((h1-h2*cosg)*np.cos(m*phi1)*legendres1[index])
                res = res/np.sqrt(h1**2 + h2**2 - 2*h1*h2*cosg) 
            else: # Filling S_lm
                res = float((h2-h1*cosg)*np.sin(-m*phi2)*legendres2[index])
                res += float((h1-h2*cosg)*np.sin(-m*phi1)*legendres1[index])
                res = res/np.sqrt(h1**2 + h2**2 - 2*h1*h2*cosg)
            amat[i][j+1] = res # j+1 because 0 is reserved for tidal amplitude
        if lmax >= 2: #pdv{c_i}{amp}=sum_{l,m} pdv{c_i}{C_{lm}}*pdv{C_{lm}}{amp}=pdv{c_i}{C_{22}}/-3*cos{phase}+pdv{c_i}{C_{20}}*cos{phase}*2/3
            amat[i][0] = (2*amat[i][5]/6.70820394-amat[i][8]/1.93649167)*np.cos(phase) #amat[i][8] is C22, amat[i][5] is C20
    return amat

def makeARadar(points, coefs, coords):
    # Makes a matrix of A_ij = dradarpoint_i/dcoef_j, using analytic solution for
    # derivatives. Includes phase info in coefs[0] (l=-1, m=0) and coords[:,2]
    lmax = int(coefs[-1][2])
    amat = np.zeros((len(points),len(coefArrayToVector(coefs,lmax))))
    # ugly but faster
    getms = np.linspace(0,len(amat[0])-1,len(amat[0]),dtype=int)
    getls = np.copy(getms)
    indices = np.copy(getms)
    for i in range(len(getms)):
        getms[i] = getM(i)
        getls[i] = getL(i)
        indices[i] = int(getls[i]*(getls[i]+1)/2+np.abs(getms[i]))
    myms = np.array(getms)[:len(amat[0])-1]
    myinds = np.array(indices)[:len(amat[i])-1]
    for i in range(len(amat)): # Makes each row of A_ij
        [phi,theta,phase] = coords[i]
        # get array of legendre polynomials, not sure if this PlmBar is the
        # normalization I want though. Note that the array that gets returned 
        # is [P00(cos(theta)),P10(),P11,P20,P21,P22,P30,P31,P32,P33,...]
        legendres = pyshtools.legendre.PlmBar(lmax, np.cos(theta))
        # Computing derivatives is much easier than for chords, follows Nimmo 2010 sec 3.2
        amat[i][1:] = legendres[myinds]*(np.cos(myms*phi)*(myms>=0)+np.sin(-myms*phi)*(myms<0))
        if lmax >= 2: #pdv{c_i}{amp}=sum_{l,m} pdv{c_i}{C_{lm}}*pdv{C_{lm}}{amp}=pdv{c_i}{C_{22}}/-3*cos{phase}+pdv{c_i}{C_{20}}*cos{phase}*2/3
            amat[i][0] = (2*amat[i][5]/6.70820394-amat[i][8]/1.93649167)*np.cos(phase) #amat[i][8] is C22, amat[i][5] is C20
    return amat
#
def makePyshtoolsObject(scoefs):
    lmax = int(scoefs[-1][2])
    scoefs = np.copy(scoefs)
    array = np.zeros((2,lmax+1,lmax+1))
    for l in range(lmax+1):
        for m in range(l+1):
            array[0][l][m] = scoefs[int(l*(l+1)/2+m)][0]
            array[1][l][m] = scoefs[int(l*(l+1)/2+m)][1]
    return pyshtools.SHCoeffs.from_array(array)

def makeSynthetics(number, coefs,lmax, tideamplitude=0,myseed=0):
    # makes 'number' synthetic chords. Note that "synthetics" refers
    # to chords here even though it refers to the shape model in 
    # the similarly named makeModifiedSynthetics(). Sorry...
    chords = []
    coords = []
    np.random.seed(myseed)
    for i in range(number):
        phi1 = random.random()*2*np.pi-np.pi
        phi2 = random.random()*2*np.pi-np.pi
        theta1 = np.arccos(2*random.random()-1)
        theta2 = np.arccos(2*random.random()-1)
        phase = random.random()*2*np.pi
        scoefs = np.copy(coefs)
        # Adds time variation to the P22 cosine term
        if tideamplitude == 0:
            coords.append([phi1,theta1,phi2,theta2])
        else:
            scoefs = changeCoef(scoefs,2,2,-1*tideamplitude*np.cos(phase)/1.93649167)
            scoefs = changeCoef(scoefs,2,0,2*tideamplitude*np.cos(phase)/6.70820394)
            coords.append([phi1,theta1,phi2,theta2,phase])
        chords.append(computeChord(phi1,theta1,phi2,theta2,scoefs,lmax))
    return (np.array(chords),np.array(coords))

def makeModifiedSynthetics(olds,factor=1,startdegree=4,myseed=0):
    # Takes a set of synthetic coefficients, fits their power spectrum (only from startdegree
    # onward), and generates a new set of synthetics from that power spectrum, with the 
    # entire power spectrum (from degree 3 onward) multipled by "factor". 
    oldclm = makePyshtoolsObject(olds)
    powers = oldclm.spectrum()
    inds = np.linspace(0,len(powers)-1,len(powers))
    fit = np.polyfit(np.log10(inds[startdegree:]),np.log10(powers[startdegree:]),1)
    fits = np.copy(powers)
    fits[startdegree:] = 10**(np.log10(inds[startdegree:])*fit[0]+fit[1])
    fits[3:] *= factor
    newclm = pyshtools.SHCoeffs.from_random(fits,seed=myseed)
    newcoefs = newclm.to_array()
    res = np.copy(olds)
    for l in range(int(olds[-1][2]+1))[3:]:
        for m in range(l+1):
            res[int(l*(l+1)/2+m)][0] = newcoefs[0][l][m]
            res[int(l*(l+1)/2+m)][1] = newcoefs[1][l][m]
    return res
    
def solve(chords, coords, lmax=5, printprogress = False):
    # Solves for best fit coefficients for a particular set of chords and coords
    # with a max degree of lmax. Uses analytic solution from Nimmo 2010
    res = np.array([[0,0,-1,0],[np.mean(chords),0,0,0]]) # Initial guesses
    for i in range(lmax+1):            
        for j in range(i+2): # Adding next set of harmonics to fit, with all guesses as 0
            if i < lmax: # no more added if we're done
                res = np.append(res,np.array([[0,0,i+1,j]]),axis=0)
    if len(coords[0]) == 4: #  if phase information wasn't included
        res = updateCs(makeA(chords,np.copy(res),np.append(coords,coords[:,0:1]*0,axis=1))[:,1:],chords,i,phase=False)
        res = np.append(np.array([[0,0,-1,0]]),res,axis=0)
    else:
        res = updateCs(makeA(chords,np.copy(res),coords),chords,i,phase=True)
    return res

def solveBoth(chords, radars, chordcoords, radarcoords, lmax=5, printprogress = False, chordweight = 1, radarweight = 1):
    # Solves for best fit coefficients for a particular set of chords and coords
    # with a max degree of lmax. Uses analytic solution from Nimmo 2010
    # Starts by fitting just degree 0, then fits degree 1, using degree 0 
    # as a guess, then degree 2 with 1 as a guess, etc.
    res = np.array([[0,0,-1,0],[np.mean(radars),0,0,0]]) # Initial guesses
    for i in range(lmax+1):
        if printprogress:
            print(res)
        if len(chordcoords[0]) == 4: #  if phase information wasn't included
            amat1 = chordweight*makeA(chords,np.copy(res),np.append(chordcoords,chordcoords[:,0:1]*0,axis=1))[:,1:]
            amat2 = radarweight*makeARadar(radars,np.copy(res),np.append(radarcoords,radarcoords[:,0:1]*0,axis=1))[:,1:]
            res = updateCs(np.append(amat1,amat2,axis=0),np.append(chordweight*chords,radarweight*radars),i,phase=False)
            res = np.append(np.array([[0,0,-1,0]]),res,axis=0)
        elif i < 2: # Fitting below degree 2 can't solve for tides
            amat1 = chordweight*makeA(chords,np.copy(res),chordcoords)[:,1:]
            amat2 = radarweight*makeARadar(radars,np.copy(res),radarcoords)[:,1:]
            res = updateCs(np.append(amat1,amat2,axis=0),np.append(chordweight*chords,radarweight*radars),i,phase=False)
            res = np.append(np.array([[0,0,-1,0]]),res,axis=0)
        else:
            amat1 = chordweight*makeA(chords,np.copy(res),chordcoords)
            amat2 = radarweight*makeARadar(radars,np.copy(res),radarcoords)
            res = updateCs(np.append(amat1,amat2,axis=0),np.append(chordweight*chords,radarweight*radars),i,phase=True)            
        for j in range(i+2): # Adding next set of harmonics to fit, with all guesses as 0
            if i < lmax: # no more added if we're done
                res = np.append(res,np.array([[0,0,i+1,j]]),axis=0)
    return res

def solveRadar(radars, radarcoords, lmax=5, printprogress = False):
    # Solves for best fit coefficients for a particular set of chords and coords
    # with a max degree of lmax. Uses analytic solution from Nimmo 2010
    # Starts by fitting just degree 0, then fits degree 1, using degree 0 
    # as a guess, then degree 2 with 1 as a guess, etc.
    res = np.array([[0,0,-1,0],[np.mean(radars),0,0,0]]) # Initial guesses
    for i in range(lmax+1):
        if printprogress:
            print(res)
        if len(radarcoords[0]) == 2: #  if phase information wasn't included
            amat = makeARadar(radars,np.copy(res),np.append(radarcoords,radarcoords[:,0:1]*0,axis=1))[:,1:]
            res = updateCs(amat,radars,i,phase=False)
            res = np.append(np.array([[0,0,-1,0]]),res,axis=0)
        elif i < 2: # Fitting below degree 2 can't solve for tides
            amat = makeARadar(radars,np.copy(res),radarcoords)[:,1:]
            res = updateCs(amat,radars,i,phase=False)
            res = np.append(np.array([[0,0,-1,0]]),res,axis=0)
        else:
            amat = makeARadar(radars,np.copy(res),radarcoords)
            res = updateCs(amat,radars,i,phase=True)            
        for j in range(i+2): # Adding next set of harmonics to fit, with all guesses as 0
            if i < lmax: # no more added if we're done
                res = np.append(res,np.array([[0,0,i+1,j]]),axis=0)
    return res
    
def updateCs(amat, chords, lmax, phase=True):
    # Solves xhat = [A^T.A]^-1.A^T.z from Nimmo 2010
    # Despite saying "chords" this works for radar points too
    amat = np.matrix(amat)
    chords = np.matrix(chords).T
    res = ((amat.T*amat).I)*(amat.T*chords)
    coefs = coefVectorToArray(np.array(res.T)[0],lmax,phase=phase)
    return coefs
