import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pyshtools
import random

from OccultationAltimetryFunctions import *


#Setting plotting font stuff
font = {'size'      : 12}
plt.rc('font',**font)

ticksize = 9
axislabelsize = 11
legendtextsize = 9
titlefontsize=14
cbarfontsize = 9
mycolors = ['#1b9e77','#d95f02','#7570b3','#e7298a']
coloralpha = 0.8


    
def plotChordsAndRadarsPaper(chordname = 'chord-coordinates.txt', radarname = 'radar-coordinates-500km.txt', savename = 'Chords-and-Radars.pdf'):
    # Used for paper figure 1, background needs to be added manually though
    radars = np.loadtxt(radarname)
    radars[:,1] = np.pi/2. - radars[:,1]
    radars = radars*180./np.pi
    chords = np.loadtxt(chordname)
    chords[:,1] = np.pi/2. - chords[:,1]
    chords[:,3] = np.pi/2. - chords[:,3]
    chords = chords*180./np.pi
    fig,ax = plt.subplots(figsize=(7.25,3.75))
    ax.scatter(radars[:,0],radars[:,1],s=1,c='black',label='Radar point')
    ax.scatter(chords[:,0],chords[:,1],s=15,c='green', label='Occultation start')
    ax.scatter(chords[:,2],chords[:,3],s=15,c='red',label='Occultation end')
    for row in chords:
        ax.plot((row[0],row[2]),(row[1],row[3]),color='blue',alpha=0.2,linewidth=0.5)
    plt.axis('scaled')
    plt.xlim(0,360)
    plt.ylim(-90,90)
    plt.xlabel('Longitude',fontsize=axislabelsize)
    plt.ylabel('Latitude',fontsize=axislabelsize)
    plt.yticks([-90,-60,-30,0,30,60,90],fontsize=ticksize)
    plt.xticks([0,90,180,270,360],fontsize=ticksize)
    plt.legend(borderpad=0.02,handletextpad=0.02,fontsize=legendtextsize-3, framealpha=.5, loc='upper left')
    plt.subplots_adjust(left=.08,right=.97,top=.99,bottom=.11)
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show() 
    return

def mapComparisonPaperTwoDegree(inputs1 = [], inputs2 = [], filenamerc = 'radar-coordinates-500km.txt', filenamecc = 'chord-coordinates.txt', filenamer = 'radar-heights-500km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax1=5, lmax2 = 8, savename="Map-Figure.pdf",fulllmax=179,vmax=False):
    # Making paper Figure 2, showing the misfit in map view for a single fit for
    # radars alone, chords alone, and both, as well as plots of the actual synthetic 
    # topography, both total and truncated.
    coordsr = np.loadtxt(filenamerc)
    coordsc = np.loadtxt(filenamecc)
    radars = np.loadtxt(filenamer)
    chords = np.loadtxt(filenamec)
    moons1 = loadMoonHarmonics(filename=filenamesynthetics, lmax=lmax1)
    moons2 = loadMoonHarmonics(filename=filenamesynthetics, lmax=lmax2)
    moonsfull = loadMoonHarmonics(filename=filenamesynthetics, lmax=fulllmax)
    cmoons1 = np.copy(moons1)
    cmoons2 = np.copy(moons2)
    cmoons1[0][0] = 0
    cmoons2[0][0] = 0
    cmoonsfull = np.copy(moonsfull)
    cmoonsfull[0][0] = 0
    if len(inputs1) == 0:
        resboth1 = solveBoth(chords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=lmax1,printprogress=False)[1:]
        resradars1 = solveRadar(radars,coordsr, lmax=lmax1,printprogress=False)[1:]
        reschords1 = solve(chords,coordsc, lmax=lmax1,printprogress=False)[1:]
    else:
        [resboth1, resradars1, reschords1] = inputs1
    if len(inputs2) == 0:
        resboth2 = solveBoth(chords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=lmax2,printprogress=False)[1:]
        resradars2 = solveRadar(radars,coordsr, lmax=lmax2,printprogress=False)[1:]
        reschords2 = solve(chords,coordsc, lmax=lmax2,printprogress=False)[1:]
    else:
        [resboth2, resradars2, reschords2] = inputs2
    [bothdiff1, radardiff1, chorddiff1] = [np.copy(moons1),np.copy(moons1),np.copy(moons1)]
    [bothdiff2, radardiff2, chorddiff2] = [np.copy(moons2),np.copy(moons2),np.copy(moons2)]
    bothdiff1[:,:2] -= resboth1[:,:2]
    radardiff1[:,:2] -= resradars1[:,:2]
    chorddiff1[:,:2] -= reschords1[:,:2]
    bothdiff2[:,:2] -= resboth2[:,:2]
    radardiff2[:,:2] -= resradars2[:,:2]
    chorddiff2[:,:2] -= reschords2[:,:2]
    [bothclm1,radarclm1,chordclm1] = [makePyshtoolsObject(bothdiff1),makePyshtoolsObject(radardiff1),makePyshtoolsObject(chorddiff1)]
    [bothclm2,radarclm2,chordclm2] = [makePyshtoolsObject(bothdiff2),makePyshtoolsObject(radardiff2),makePyshtoolsObject(chorddiff2)]
    [moonsclm1,moonsclm2,moonsfullclm] = [makePyshtoolsObject(cmoons1),makePyshtoolsObject(cmoons2),makePyshtoolsObject(cmoonsfull)]
    [bothgrid1,radargrid1,chordgrid1] = [bothclm1.expand(),radarclm1.expand(),chordclm1.expand()]
    [bothgrid2,radargrid2,chordgrid2] = [bothclm2.expand(),radarclm2.expand(),chordclm2.expand()]
    [moonsgrid1,moonsgrid2,moonsfullgrid] = [moonsclm1.expand(),moonsclm2.expand(),moonsfullclm.expand()]
    myvmax1 = np.max(np.abs(np.array([bothgrid1.to_array().max(),bothgrid1.to_array().min(),np.min(np.abs(np.array([radargrid1.to_array().max(),radargrid1.to_array().min()]))),chordgrid1.to_array().max(),chordgrid1.to_array().min()])))
    myvmax1 = min(myvmax1,5.)    
    myvmin1 = -1*myvmax1
    myvmax2 = np.max(np.abs(np.array([bothgrid2.to_array().max(),bothgrid2.to_array().min(),np.min(np.abs(np.array([radargrid2.to_array().max(),radargrid2.to_array().min()]))),chordgrid2.to_array().max(),chordgrid2.to_array().min()])))
    myvmax2 = min(myvmax2,5.)
    myvmin2 = -1*myvmax2
    plt.close()
    fig = plt.figure(1,figsize=(7.25,8.5))
    ax0 = plt.subplot2grid((5,2),(0,0),colspan=2,rowspan=1)
    ax1 = [plt.subplot2grid((5,2),(1,0)),plt.subplot2grid((5,2),(2,0)),plt.subplot2grid((5,2),(3,0)),plt.subplot2grid((5,2),(4,0))]
    ax2 = [plt.subplot2grid((5,2),(1,1)),plt.subplot2grid((5,2),(2,1)),plt.subplot2grid((5,2),(3,1)),plt.subplot2grid((5,2),(4,1))]
    moonsfullgrid.plot(ax=ax0,colorbar='right', show=False, cmap='RdBu',cmap_limits=[-2.5,2.5])
    moonsgrid1.plot(ax=ax1[0],colorbar='right', show=False, cmap='RdBu',cmap_limits=[-2.5,2.5])
    radargrid1.plot(ax=ax1[1],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin1,myvmax1])
    chordgrid1.plot(ax=ax1[2],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin1,myvmax1])
    bothgrid1.plot(ax=ax1[3],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin1,myvmax1])
    moonsgrid2.plot(ax=ax2[0],colorbar='right', show=False, cmap='RdBu',cmap_limits=[-2.5,2.5])
    radargrid2.plot(ax=ax2[1],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin2,myvmax2])
    chordgrid2.plot(ax=ax2[2],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin2,myvmax2])
    bothgrid2.plot(ax=ax2[3],colorbar='right', show=False, cmap='RdBu',cmap_limits=[myvmin2,myvmax2])
    ax0.set_title('Full Synthetic Topography\n',fontsize=titlefontsize)
    ax0.images[-1].colorbar.ax.set_title('Height (km)',fontsize=cbarfontsize+1)
    ax0.set_xlabel('', fontsize=0)
    ax0.set_ylabel('', fontsize=0)
    ax0.set_yticks(ax0.get_yticks())
    ax0.set_xticklabels(ax2[3].get_xticklabels()[::3], fontsize=ticksize)
    ax0.set_yticklabels(ax0.get_yticklabels(), fontsize=ticksize) 
    ax0.set_xticks(ax1[3].get_xticks()[::3])
    for axis in ax1+ax2:
        axis.images[-1].colorbar.ax.tick_params(labelsize=cbarfontsize-1)
        axis.set_yticklabels(axis.get_yticklabels(),fontsize=ticksize-1)
        axis.set_xlabel('',fontsize=0)
        axis.set_ylabel('',fontsize=0) 
        axis.set_xticklabels(axis.get_xticklabels()[::3], fontsize=ticksize) 
        axis.set_xticks(axis.get_xticks()[::3])
    for axis in ax2:        
        axis.images[-1].colorbar.ax.set_title('\nHeight (km)', fontsize=cbarfontsize-1)
    ############# Putting shared titles on each row, requires identifying the coordinates for the title
    texts = list(range(len(ax1)))
    for i in range(len(texts)):
        texts[i] = [ax1[i].set_title(' ',fontsize=titlefontsize),ax2[i].set_title(' ',fontsize=titlefontsize)]    
    plt.tight_layout(h_pad=.5)    
    fig.subplots_adjust(left=0.045,bottom=0.023,right=0.96,top=.94)
    fig.canvas.draw()
    locs = list(range(len(texts)))
    leftlocs = list(range(len(texts)))
    rightlocs = list(range(len(texts)))
    for i in range(len(locs)):
        locations = [fig.transFigure.inverted().transform(texts[i][0].get_window_extent(renderer=fig.canvas.renderer)),fig.transFigure.inverted().transform(texts[i][1].get_window_extent(renderer=fig.canvas.renderer))]
        locs[i] = [(locations[0][0][0] + locations[1][0][0])/2.,locations[0][1][1]]
        leftlocs[i] = [locations[0][0][0],locations[0][1][1]]
        rightlocs[i] = [locations[1][0][0],locations[0][1][1]]
    fig.text(leftlocs[0][0],leftlocs[0][1]+.003,'Degree '+str(lmax1),horizontalalignment='center',verticalalignment='bottom',fontsize=titlefontsize+1)
    fig.text(rightlocs[0][0],leftlocs[0][1]+.003,'Degree '+str(lmax2),horizontalalignment='center',verticalalignment='bottom',fontsize=titlefontsize+1)
    fig.text(locs[0][0],locs[0][1]-.0057,'\nTruncated Synthetic Topography\n',horizontalalignment='center',verticalalignment='center',fontsize=titlefontsize)
    fig.text(locs[1][0],locs[1][1],'Misfit, Radar data only',horizontalalignment='center',verticalalignment='top',fontsize=titlefontsize)
    fig.text(locs[2][0],locs[2][1],'Misfit, Occultation data only',horizontalalignment='center',verticalalignment='top',fontsize=titlefontsize)
    fig.text(locs[3][0],locs[3][1],'Misfit, Combined datasets',horizontalalignment='center',verticalalignment='top',fontsize=titlefontsize)
    fig.subplots_adjust(left=0.035,bottom=0.023,right=0.97,top=.94)
    if savename==str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return [[resboth1,resradars1,reschords1],[resboth2,resradars2,reschords2]]
     
def MisfitVsDegreePaper(misfitboth=[], misfitchords=[], misfitradars = [], filenamerc = 'radar-coordinates-500km.txt', filenamecc = 'chord-coordinates.txt', filenamer = 'radar-heights-500km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax=20,savename="Misfit-Vs-Degree-Figure.pdf"):
    # Making paper figure 3A comparing radars alone, chords alone, and both
    # note there was a mistake in the version that made it into LPSC, misfitchords
    # pulled from resradars and vice versa.
    coordsr = np.loadtxt(filenamerc)
    coordsc = np.loadtxt(filenamecc)
    radars = np.loadtxt(filenamer)
    chords = np.loadtxt(filenamec)
    if len(misfitboth)*len(misfitchords)*len(misfitradars) == 0:
        misfitboth = []
        misfitchords = []
        misfitradars = []
        for l in range(lmax+1):            
            print("Degree " + str(l) + " complete, out of " + str(lmax)) 
            moons = loadMoonHarmonics(filename=filenamesynthetics, lmax=l)
            resboth = solveBoth(chords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=l,printprogress=False)[1:]
            resradars = solveRadar(radars,coordsr, lmax=l,printprogress=False)[1:]
            reschords = solve(chords,coordsc, lmax=l,printprogress=False)[1:]
            misfitboth.append(np.sqrt(np.sum((resboth[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitchords.append(np.sqrt(np.sum((reschords[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitradars.append(np.sqrt(np.sum((resradars[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
    markersize=16
    markershape='D'
    plt.figure(figsize=(3.5,2.5))
    plt.scatter(list(range(len(misfitboth))),misfitboth,label='Both datasets',s=markersize,marker=markershape,color=mycolors[0],alpha=coloralpha)
    plt.scatter(list(range(len(misfitchords))),misfitchords,label='Occultation data only',s=markersize,marker=markershape,color=mycolors[1],alpha=coloralpha)
    plt.scatter(list(range(len(misfitradars))),misfitradars,label='Radar data only',s=markersize,marker=markershape,color=mycolors[2],alpha=coloralpha)
    plt.legend(borderpad=0.2,handletextpad=0.02,fontsize=legendtextsize)
    plt.xticks(list(range(lmax+1))[::2],fontsize=ticksize)
    plt.yticks(fontsize=ticksize)
    plt.xlabel('Max degree in fit',fontsize=axislabelsize)
    plt.ylabel('RMS misfit (km)',fontsize=axislabelsize)
    plt.xlim(1.5,lmax)
    plt.ylim(0,0.5)
    plt.subplots_adjust(left=.15,right=.95,top=.95,bottom=.2)
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return (misfitboth,misfitchords,misfitradars)

def PaperAllowedMisfitVsDegree(filenamerc = 'radar-coordinates-500km.txt', filenamecc = 'chord-coordinates.txt', filenamer = 'radar-heights-500km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax=20,savename="Allowed-Misfit-Vs-Degree.pdf", trials = 20, inputs = [],randomseed=0,synlmax=60):
    # Making figure 3B. Lower "trials" to speed it up. Lowering "lmax" will 
    # help, but you also actually lose some information
    if len(inputs) == 0:
        coordsc = np.loadtxt(filenamecc)
        coordsr = np.loadtxt(filenamerc)
        misfitboth = []
        misfitchords = []
        misfitradars = []
        moons = loadMoonHarmonics(filename=filenamesynthetics, lmax=synlmax)
        for t in range(trials):
            bothe = []
            chordse = []
            radarse = []
            print(str(t) + " out of " + str(trials) + " trials completed")
            if t != 0:
                coefs = makeModifiedSynthetics(moons,myseed=randomseed+t)
                chords = np.array(makeChords(coordsc,coefs,False,synlmax))
                radars = np.array(makeRadars(coordsr,coefs,False,synlmax))
            else:
                coefs = np.copy(moons)
                chords = np.loadtxt(filenamec)
                radars = np.loadtxt(filenamer)
            for l in range(lmax+1):
                resboth = solveBoth(chords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=l,printprogress=False)[1:]
                resradars = solveRadar(radars,coordsr, lmax=l,printprogress=False)[1:]
                reschords = solve(chords,coordsc, lmax=l,printprogress=False)[1:]
                ind = int((l+1)*(l+2)/2)
                bothe.append(np.sqrt(np.sum((resboth[:,:2] - coefs[:ind,:2])**2)/np.sum(coefs[:ind,:2]!=0)))
                chordse.append(np.sqrt(np.sum((reschords[:,:2] - coefs[:ind,:2])**2)/np.sum(coefs[:ind,:2]!=0)))
                radarse.append(np.sqrt(np.sum((resradars[:,:2] - coefs[:ind,:2])**2)/np.sum(coefs[:ind,:2]!=0)))
            misfitboth.append(bothe)
            misfitradars.append(radarse)
            misfitchords.append(chordse)
        # Swapping t and l for loops to make things run faster
        misfitboth=np.swapaxes(misfitboth,0,1)
        misfitchords=np.swapaxes(misfitchords,0,1)
        misfitradars=np.swapaxes(misfitradars,0,1)
        # Makes the first column the average of all the rest
        misfitboth = np.append(np.swapaxes([np.mean(misfitboth,axis=1)],0,1),misfitboth,axis=1)
        misfitradars = np.append(np.swapaxes([np.mean(misfitradars,axis=1)],0,1),misfitradars,axis=1)
        misfitchords = np.append(np.swapaxes([np.mean(misfitchords,axis=1)],0,1),misfitchords,axis=1)
    else:
        misfitboth = inputs[0]
        misfitradars = inputs[1]
        misfitchords = inputs[2]
    fig,ax = plt.subplots(figsize=(3.5,2.5))
    for run in range(len(misfitboth[0])):
        bothlims = []
        chordlims = []
        radarlims = []
        bothinds = []
        radarinds = []
        chordinds = []
        misfitlist = np.append(np.append(np.copy(misfitchords[:,run]),np.copy(misfitboth[:,run])),np.copy(misfitradars[:,run]))
        misfitlist.sort()
        for misfit in misfitlist:
            bothlist = np.where(np.array(misfitboth[:,run])<=misfit)[0]
            radarlist = np.where(np.array(misfitradars[:,run])<=misfit)[0]
            chordlist = np.where(np.array(misfitchords[:,run])<=misfit)[0]                
            if len(bothlist) > 0:
                bothinds.append(np.max(bothlist))
                bothlims.append(misfit)
            if len(radarlist) > 0:
                radarinds.append(np.max(radarlist))
                radarlims.append(misfit)
            if len(chordlist) > 0:
                chordinds.append(np.max(chordlist))
                chordlims.append(misfit)
        if run == 0:
            myalpha = coloralpha
            mylabels = ['Both','Chords','Radars']
        # Makes non-averaged lines be fainter
        else:
            myalpha = coloralpha/trials*2
            mylabels = [None,None,None]
        plt.plot(bothlims,bothinds, label=mylabels[0],color=mycolors[0],alpha=myalpha)
        plt.plot(chordlims,chordinds, label=mylabels[1],color=mycolors[1],alpha=myalpha)
        plt.plot(radarlims,radarinds, label=mylabels[2],color=mycolors[2],alpha=myalpha)
    plt.legend(borderpad=0.5,handletextpad=0.5,fontsize=legendtextsize, framealpha=.5)
    plt.yticks([5,10,15,20],['5','10','15','20'],fontsize=ticksize)
    plt.xscale('log')
    plt.xticks([.01,.03,.1,.3,1],['0.01','0.03','0.1','0.3','1'],fontsize=ticksize)
    plt.xlabel('Max RMS Misfit Allowed (km)',fontsize=axislabelsize)
    plt.ylabel('Degree fittable',fontsize=axislabelsize)
    plt.xlim(.01,1)
    plt.subplots_adjust(left=.15,right=.95,top=.95,bottom=.2)
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return (misfitboth,misfitradars,misfitchords)

def PaperPlotAddingNoise(inputs = [], filenamerc = 'radar-coordinates-500km.txt', filenamecc = 'chord-coordinates.txt', filenamer = 'radar-heights-500km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax=5,savename="Noise-Test-Figure.pdf", chorderrors = [0.001,0.01,0.03,0.1,0.2,0.4,0.6,1.,2.], trials = 150, finish=True,label="Radars and Chords",datasavename = False, ax=False,cloud=True):
    # Making paper figure 4, note that this currently makes 4a, change 
    # "lmax" to 8 for 4b, and drop trialsor shorten chorderrors to speed it up
    if len(inputs) == 0:
        botharray = []
        chordarray = []
        l = lmax
        moons = loadMoonHarmonics(filename=filenamesynthetics, lmax=l)
        coordsc = np.loadtxt(filenamecc)
        chords = np.loadtxt(filenamec)
        coordsr = np.loadtxt(filenamerc)
        radars =  np.loadtxt(filenamer)
        resradar = solveRadar(radars,coordsr, lmax=l,printprogress=False)[1:]
        radarmisfit = np.sqrt(np.sum((resradar[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0))
        for trial in range(trials):
            print(str(trial) + " out of " + str(trials) + " trials completed.")
            bothmisfits = []
            chordmisfits = []
            for cerr in chorderrors:
                print(cerr)
                echords = chords+(np.random.random(len(chords))-0.5)*2*np.sqrt(2)*cerr
                reschord = solve(echords,coordsc, lmax=l,printprogress=False)[1:]
                chordmisfits.append(np.sqrt(np.sum((reschord[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
                resboth = solveBoth(echords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=l,printprogress=False)[1:]
                bothmisfits.append(np.sqrt(np.sum((resboth[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            botharray.append(bothmisfits)
            chordarray.append(chordmisfits)
            if datasavename == str(datasavename):
                np.savetxt(datasavename+'both',np.array(botharray))
                np.savetxt(datasavename+'chord',np.array(chordarray))
#                np.savetxt(datasavename+'radar',np.array(radarmisfit))
#                np.savetxt(datasavename+'chorde',np.array(chorderrors))
    else:
        botharray = inputs[0]
        chordarray = inputs[1]
        radarmisfit = inputs[2]
        chorderrors = inputs[3]
    fig,ax = plt.subplots(figsize=(3.5,2.5))
    if cloud:    
        for trial in range(trials):
            bothmisfits = botharray[trial]
            chordmisfits = chordarray[trial]
            ax.plot(chorderrors,bothmisfits,color=mycolors[0],alpha=coloralpha/(trials/3.))
            ax.plot(chorderrors,chordmisfits,color=mycolors[1],alpha=coloralpha/(trials/3.))
    ax.plot(chorderrors,np.mean(botharray,axis=0),label='both',color=mycolors[0],alpha=coloralpha)
    ax.plot(chorderrors,np.mean(chordarray,axis=0),label='chords',color=mycolors[1],alpha=coloralpha)
    ax.plot(chorderrors,np.array(chorderrors)/np.array(chorderrors)*radarmisfit,label='radar',color=mycolors[2],alpha=coloralpha,dashes=(4,4))
    ax.set_xscale('log')
    ax.set_yscale('log')
    plt.yticks([.1,.3,1],['0.1','0.3','1'],fontsize=ticksize)
    plt.xticks([.001,.01,.1,1],['0.001','0.01','0.1','1'],fontsize=ticksize)
    plt.xlabel('Occultation Length Uncertainty (km)',fontsize=axislabelsize)
    plt.ylabel('RMS Misfit (km)',fontsize=axislabelsize)
    plt.ylim(.01,.3)
    plt.xlim(np.min(chorderrors),np.max(chorderrors))
    plt.title('Degree ' + str(lmax))
    fig.subplots_adjust(left=.16,right=.95,top=.95,bottom=.2)
    plt.legend()   
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return [botharray,chordarray,radarmisfit,chorderrors]

def paperComparisonPlotAltitudes(filenamerc2 = 'radar-coordinates-200km.txt', filenamerc5 = 'radar-coordinates-500km.txt', filenamerc10 = 'radar-coordinates-1000km.txt',filenamecc = 'chord-coordinates.txt', filenamer2 = 'radar-heights-200km.txt', filenamer5 = 'radar-heights-500km.txt', filenamer10 = 'radar-heights-1000km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax=20,savename="Altitude-Comparison-Figure.pdf",inputs=[]):
    # Making paper figure 5, showing the effect of varying radar altitude
    # This assumes the sparsely sampled (1 out of every 20 radar points) radar
    # datasets, which improves speed without mattering for fit quality.
    if len(inputs) == 0:
        coordsr2 = np.loadtxt(filenamerc2)
        coordsr5 = np.loadtxt(filenamerc5)
        coordsr10 = np.loadtxt(filenamerc10)
        coordsc = np.loadtxt(filenamecc)
        radars2 = np.loadtxt(filenamer2)
        radars5 = np.loadtxt(filenamer5)
        radars10 = np.loadtxt(filenamer10)
        chords = np.loadtxt(filenamec)
        misfitboth2 = []
        misfitboth5 = []
        misfitboth10 = []
        misfitchords = []
        misfitradars2 = []
        misfitradars5 = []
        misfitradars10 = []
        for l in range(lmax+1):
            print("Degree " + str(l) + " complete, out of " + str(lmax)) 
            moons = loadMoonHarmonics(filename=filenamesynthetics, lmax=l)
            resboth2 = solveBoth(chords,radars2,coordsc,coordsr2,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars2))), lmax=l,printprogress=False)[1:]
            resboth5 = solveBoth(chords,radars5,coordsc,coordsr5,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars5))), lmax=l,printprogress=False)[1:]
            resboth10 = solveBoth(chords,radars10,coordsc,coordsr10,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars10))), lmax=l,printprogress=False)[1:]
            resradars2 = solveRadar(radars2,coordsr2, lmax=l,printprogress=False)[1:]
            resradars5 = solveRadar(radars5,coordsr5, lmax=l,printprogress=False)[1:]
            resradars10 = solveRadar(radars10,coordsr10, lmax=l,printprogress=False)[1:]
            reschords = solve(chords,coordsc, lmax=l,printprogress=False)[1:]
            misfitboth2.append(np.sqrt(np.sum((resboth2[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitboth5.append(np.sqrt(np.sum((resboth5[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitboth10.append(np.sqrt(np.sum((resboth10[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitchords.append(np.sqrt(np.sum((reschords[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitradars2.append(np.sqrt(np.sum((resradars2[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitradars5.append(np.sqrt(np.sum((resradars5[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
            misfitradars10.append(np.sqrt(np.sum((resradars10[:,:2] - moons[:,:2])**2)/np.sum(moons[:,:2]!=0)))
    else:
        (misfitboth2,misfitboth5,misfitboth10,misfitchords,misfitradars2,misfitradars5,misfitradars10) = inputs
    plt.figure(figsize=(3.5,2.5))
    dashsize=3
    plt.plot(list(range(len(misfitchords))),misfitchords,label='Occultation only',color=mycolors[1],alpha=coloralpha)
    plt.plot(list(range(len(misfitboth2))),misfitboth2,label='Both, 200 km',color=mycolors[0],alpha=coloralpha)
    plt.plot(list(range(len(misfitradars2))),misfitradars2,label='Radar, 200 km',color=mycolors[0],alpha=coloralpha,dashes=(dashsize,dashsize))
    plt.plot(list(range(len(misfitboth5))),misfitboth5,label='Both, 500 km',color=mycolors[2],alpha=coloralpha)
    plt.plot(list(range(len(misfitradars5))),misfitradars5,label='Radar, 500 km',color=mycolors[2],alpha=coloralpha,dashes=(dashsize,dashsize))
    plt.plot(list(range(len(misfitboth10))),misfitboth10,label='Both, 1000 km',color=mycolors[3],alpha=coloralpha)
    plt.plot(list(range(len(misfitradars10))),misfitradars10,label='Radar, 1000 km',color=mycolors[3],alpha=coloralpha,dashes=(dashsize,dashsize))
    plt.legend(borderpad=0.2,handletextpad=0.02,fontsize=legendtextsize-2, framealpha=.5, loc='upper left')
    plt.yticks(fontsize=ticksize)
    plt.xticks(list(range(lmax+1))[::2],fontsize=ticksize)
    plt.xlabel('Max harmonic degree included in fit',fontsize=axislabelsize)
    plt.ylabel('RMS misfit (km)',fontsize=axislabelsize)
    plt.ylim(0,1)
    plt.xlim(None,lmax)
    plt.subplots_adjust(left=.15,right=.95,top=.95,bottom=.2)
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return (misfitboth2,misfitboth5,misfitboth10,misfitchords,misfitradars2,misfitradars5,misfitradars10)


def paperTidePlot(coordsfilename='chord-coordinates.txt',coefsfilename='synthetic-harmonics.txt', filenamesynthetics = 'synthetic-harmonics.txt', savename="Tide-Plot.pdf", trials=1000, startseed=0, tideamplitude=1., realtideamplitude=0.03, synlmax=60, lmax=4, inputs=[]):    
    # Making paper figure 6
    # lmax=4 seems to be the best to fit tides (even though we only inject degree 2 tides)
    coords = np.loadtxt(coordsfilename)
    if len(inputs) == 0:
        tides = []
        for i in range(trials):
            if i%int(1+trials/50) == 0: 
                print(str(i) + " out of " + str(trials) + " trials completed")
            ps = np.copy(coords[:,0:1])
            for j in range(len(ps)):
                ps[j][0] = 2*np.pi*random.random()
            tidecoords = np.append(coords,ps,axis=1)
            coefs = np.append([[tideamplitude,0,-1,0]],loadMoonHarmonics(coefsfilename,synlmax),axis=0)
            chords = makeChords(tidecoords,coefs,True,synlmax)
            res = solve(chords,tidecoords,lmax=lmax)
            tides.append(tideamplitude-res[0][0])
    else:
        tides = inputs
    fig,ax = plt.subplots(figsize=(3.5,2.5))
    ax.hist(tides,density=False,bins=np.linspace(-10*realtideamplitude,10*realtideamplitude,41), color=mycolors[0])
    linewidth=3    
    ax.axvline(x=realtideamplitude,label='tidal amplitude',dashes=(4,4),color=mycolors[1],linewidth=linewidth)
    ax.axvline(x=-realtideamplitude,label='tidal amplitude',dashes=(4,4),color=mycolors[1],linewidth=linewidth)
    ax.set_yticklabels((ax.get_yticks()*100/trials).astype(int)/100.,fontsize=ticksize)
    plt.yticks(fontsize=ticksize)
    plt.xticks(fontsize=ticksize)
    plt.xlabel('Tidal amplitude misfit (km)',fontsize=axislabelsize)
    plt.ylabel('Frequency',fontsize=axislabelsize)
    plt.xlim(-0.25,0.25)
    fig.subplots_adjust(left=.17,right=.95,top=.95,bottom=.2)
    if savename == str(savename):
        plt.savefig(savename)
        plt.close()
    else:
        plt.show()
    return tides

def DataForMisfitTable(filenamerc = 'radar-coordinates-500km.txt', filenamecc = 'chord-coordinates.txt', filenamer = 'radar-heights-500km.txt', filenamec = 'chord-lengths.txt', filenamesynthetics = 'synthetic-harmonics.txt', lmax=10,savename="Allowed-Misfit-Vs-Degree.pdf", trials = 100, inputs = [],randomseed=11,synlmax=60):
    # This doesn't make a figure, it generates the randomly perturbed fits to
    # produce the values in Table 1. It returns a 4 dimensional array
    # where the first index is 0 for combined fits, 1 for only chords, and 2 
    # for only radar data. The second index is the max degree/order included
    # in that fit, the third index allows picking out specific degrees/orders
    # using the same numbering as synthetic-harmonics.txt, with 3 for C/S20, 
    # 5 for C/S22, 10 for C/S40, etc. The final index is 0 for Cij and 1 for S
    coordsc = np.loadtxt(filenamecc)
    coordsr = np.loadtxt(filenamerc)
    misfitboth = np.zeros((lmax+1,int((lmax+1)*(lmax+2)/2),2))
    misfitchords = np.zeros((lmax+1,int((lmax+1)*(lmax+2)/2),2))
    misfitradars = np.zeros((lmax+1,int((lmax+1)*(lmax+2)/2),2))
    moons = loadMoonHarmonics(filename=filenamesynthetics, lmax=synlmax)
    for t in range(trials):
        print(str(t) + " out of " + str(trials) + " trials completed")
        if t != 0:
            coefs = makeModifiedSynthetics(moons,myseed=randomseed+t)
            chords = np.array(makeChords(coordsc,coefs,False,synlmax))
            radars = np.array(makeRadars(coordsr,coefs,False,synlmax))
        else:
            coefs = np.copy(moons)
            chords = np.loadtxt(filenamec)
            radars = np.loadtxt(filenamer)
        for l in range(lmax+1):
            resboth = solveBoth(chords,radars,coordsc,coordsr,chordweight=1./np.sqrt(len(chords)),radarweight=1./(np.sqrt(len(radars))), lmax=l,printprogress=False)[1:]
            resradars = solveRadar(radars,coordsr, lmax=l,printprogress=False)[1:]
            reschords = solve(chords,coordsc, lmax=l,printprogress=False)[1:]
            ind = int((l+1)*(l+2)/2)
            misfitboth[l][:ind] += (resboth[:,:2] - coefs[:ind,:2])**2/float(trials)
            misfitradars[l][:ind] += (reschords[:,:2] - coefs[:ind,:2])**2/float(trials)
            misfitchords[l][:ind] += (resradars[:,:2] - coefs[:ind,:2])**2/float(trials)
    return np.array([misfitboth,misfitradars,misfitchords])
